//>>built
define("dijit/_editor/nls/sk/LinkDialog",({createLinkTitle:"Vlastnosti prepojenia",insertImageTitle:"Vlastnosti obrázka",url:"Adresa URL:",text:"Opis:",target:"Cieľ:",set:"Nastaviť",currentWindow:"Aktuálne okno",parentWindow:"Rodičovské okno",topWindow:"Najvyššie okno",newWindow:"Nové okno"}));
